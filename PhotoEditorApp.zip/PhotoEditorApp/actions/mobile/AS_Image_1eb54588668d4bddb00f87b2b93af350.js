function AS_Image_1eb54588668d4bddb00f87b2b93af350(eventobject, x, y) {
    setCompositionEditor(kony.filter.SOURCE_ATOP_COMPOSITING);
}