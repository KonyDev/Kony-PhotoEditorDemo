function AS_ListBox_a015a244743e4996aee3d2fe51141420(eventobject) {
    camera_FlashMode();
}