function AS_Image_fa1cd07d1ddc4b05afddce63569014b0(eventobject, x, y) {
    applyFilterttoImageIphone(filter5);
}