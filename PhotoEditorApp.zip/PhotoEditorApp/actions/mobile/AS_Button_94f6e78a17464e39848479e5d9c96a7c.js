function AS_Button_94f6e78a17464e39848479e5d9c96a7c(eventobject) {
    setBlurnessIphone(kony.filter.DiSC_BLUR);
}