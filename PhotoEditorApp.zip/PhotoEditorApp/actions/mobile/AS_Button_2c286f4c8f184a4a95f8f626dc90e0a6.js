function AS_Button_2c286f4c8f184a4a95f8f626dc90e0a6(eventobject) {
    cropImage();
}