function AS_Image_e399d599eff44a66a0e6064e6d313f97(eventobject, x, y) {
    frm2.show();
}