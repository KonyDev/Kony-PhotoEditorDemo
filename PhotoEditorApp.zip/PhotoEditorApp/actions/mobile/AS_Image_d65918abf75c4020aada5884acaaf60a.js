function AS_Image_d65918abf75c4020aada5884acaaf60a(eventobject, x, y) {
    colorstaus = "simulation";
    finalImageObject = finalImageObject1;
    setSaturationFuncIphone();
}