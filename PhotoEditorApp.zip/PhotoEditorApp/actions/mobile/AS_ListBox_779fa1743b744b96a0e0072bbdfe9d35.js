function AS_ListBox_779fa1743b744b96a0e0072bbdfe9d35(eventobject) {
    camera_videoFormatProperty();
}