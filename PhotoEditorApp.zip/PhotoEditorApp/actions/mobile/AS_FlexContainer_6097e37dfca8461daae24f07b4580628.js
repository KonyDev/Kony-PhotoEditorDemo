function AS_FlexContainer_6097e37dfca8461daae24f07b4580628() {
    frmHome.flextemp1.isVisible = false;
    frmHome.forceLayout();
}