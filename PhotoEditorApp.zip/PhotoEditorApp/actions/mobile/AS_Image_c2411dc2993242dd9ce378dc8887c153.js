function AS_Image_c2411dc2993242dd9ce378dc8887c153(eventobject, x, y) {
    frm2.show();
}