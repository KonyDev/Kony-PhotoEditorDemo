function AS_Form_2782effcfe0a4f4d8605dab36e1ba7a6(eventobject) {
    frmHome.Camera0b80625cf993243.focusMode = constants.CAMERA_FOCUS_MODE_AUTO;
}