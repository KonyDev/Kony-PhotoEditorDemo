function AS_Button_cf865f8acf8e4917971ec8fc876ca8e5(eventobject) {
    camera_captureSource_Toggle();
}