function AS_Image_b7b032b804ad4b4886908689b8b5f66a(eventobject, x, y) {
    colorstaus = "hue";
    finalImageObject = finalImageObject1;
    setHueFuncIphone();
}