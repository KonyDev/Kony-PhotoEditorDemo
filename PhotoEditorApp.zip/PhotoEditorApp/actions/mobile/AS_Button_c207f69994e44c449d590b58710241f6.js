function AS_Button_c207f69994e44c449d590b58710241f6(eventobject, x, y) {
    applyCropImage();
}