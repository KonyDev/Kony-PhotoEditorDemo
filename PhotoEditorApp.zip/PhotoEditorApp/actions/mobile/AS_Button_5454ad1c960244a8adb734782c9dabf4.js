function AS_Button_5454ad1c960244a8adb734782c9dabf4(eventobject) {
    return openGallery.call(this);
}