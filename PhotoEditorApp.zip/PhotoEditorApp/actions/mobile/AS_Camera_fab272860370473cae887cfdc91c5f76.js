function AS_Camera_fab272860370473cae887cfdc91c5f76(eventobject) {
    return openGalleryVideo.call(this);
}