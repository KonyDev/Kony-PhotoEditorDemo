function AS_Image_934bbb6bf37440849bde627129e3edad(eventobject, x, y) {
    applyFilterttoImageIphone(filter2);
}