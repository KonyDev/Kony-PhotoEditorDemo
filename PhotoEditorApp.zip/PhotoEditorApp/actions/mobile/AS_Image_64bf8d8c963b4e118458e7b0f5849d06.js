function AS_Image_64bf8d8c963b4e118458e7b0f5849d06(eventobject, x, y) {
    setCompositionEditor(kony.filter.DARKEN_COMPOSITING);
}