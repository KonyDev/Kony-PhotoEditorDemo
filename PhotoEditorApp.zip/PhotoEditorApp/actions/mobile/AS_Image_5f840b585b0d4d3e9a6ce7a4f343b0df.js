function AS_Image_5f840b585b0d4d3e9a6ce7a4f343b0df(eventobject, x, y) {
    frmVideo.forceLayout();
    frmVideo.show();
}