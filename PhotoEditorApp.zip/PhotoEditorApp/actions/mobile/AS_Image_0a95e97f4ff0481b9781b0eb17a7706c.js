function AS_Image_0a95e97f4ff0481b9781b0eb17a7706c(eventobject, x, y) {
    setBlurness(30);
}