function AS_ListBox_6578dfeab0f54344b78eabdcdda14c44(eventobject) {
    camera_FlashMode();
}