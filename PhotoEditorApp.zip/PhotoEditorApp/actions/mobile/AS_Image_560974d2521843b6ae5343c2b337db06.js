function AS_Image_560974d2521843b6ae5343c2b337db06(eventobject, x, y) {
    frmVideo.forceLayout();
    frmVideo.show();
}