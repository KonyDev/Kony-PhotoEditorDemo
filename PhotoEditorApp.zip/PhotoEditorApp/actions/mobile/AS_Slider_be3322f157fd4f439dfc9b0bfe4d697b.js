function AS_Slider_be3322f157fd4f439dfc9b0bfe4d697b(eventobject, selectedvalue) {
    setBlurnessIphone();
}