function AS_Slider_dce3cf58f436431da0bda692cb670574(eventobject, selectedvalue) {
    setColorfunIphione();
}