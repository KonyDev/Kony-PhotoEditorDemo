function AS_Image_496a6ddf7af64c7996b1af8d6454b74c(eventobject, x, y) {
    setBlurness(10);
}