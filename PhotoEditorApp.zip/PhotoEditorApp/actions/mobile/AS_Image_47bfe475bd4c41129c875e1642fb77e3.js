function AS_Image_47bfe475bd4c41129c875e1642fb77e3(eventobject, x, y) {
    setCompositionEditor(kony.filter.MULTIPLY_COMPOSITING);
}