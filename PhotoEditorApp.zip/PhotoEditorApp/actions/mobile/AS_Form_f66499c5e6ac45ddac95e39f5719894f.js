function AS_Form_f66499c5e6ac45ddac95e39f5719894f(eventobject) {
    frmCropPreview.destroy();
}