function AS_Form_c4f2b02f65bc4e9cac1a9e8f800ea6f7(eventobject) {
    frmOverlay.FrontCamera.cameraOptions = {
        hideControlBar: true
    };
    frmOverlay1.RearCamera.cameraOptions = {
        hideControlBar: true
    };
}