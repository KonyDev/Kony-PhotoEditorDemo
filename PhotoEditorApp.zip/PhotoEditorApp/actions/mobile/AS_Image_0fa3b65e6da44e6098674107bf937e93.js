function AS_Image_0fa3b65e6da44e6098674107bf937e93(eventobject, x, y) {
    applyFilterttoImage(filter1);
}