function AS_Camera_33ca21e118554a35bf53e8e1c2c5f190(eventobject) {
    return openGalleryVideo.call(this);
}