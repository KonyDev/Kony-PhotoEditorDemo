function AS_Slider_b24ae4d085c540ef8a1d61c62302cfe6(eventobject, selectedvalue) {
    setBrightnessFunc();
}