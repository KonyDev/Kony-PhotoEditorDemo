function AS_Image_1c6363c29347452c81d523f2cb0a93a5(eventobject, x, y) {
    setColorClampAndroid();
    applyFilterttoImage(filter4);
}