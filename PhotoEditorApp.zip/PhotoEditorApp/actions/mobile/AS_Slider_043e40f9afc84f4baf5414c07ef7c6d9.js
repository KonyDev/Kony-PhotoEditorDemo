function AS_Slider_043e40f9afc84f4baf5414c07ef7c6d9(eventobject, selectedvalue) {
    setBrightnessFunc();
}