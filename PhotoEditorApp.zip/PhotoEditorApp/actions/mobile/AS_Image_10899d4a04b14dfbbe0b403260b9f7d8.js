function AS_Image_10899d4a04b14dfbbe0b403260b9f7d8(eventobject, x, y) {
    applyFilterttoImageIphone(filter1);
}