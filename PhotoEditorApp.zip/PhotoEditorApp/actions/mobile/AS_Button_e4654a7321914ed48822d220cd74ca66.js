function AS_Button_e4654a7321914ed48822d220cd74ca66(eventobject) {
    frmOverlay.FrontCamera.takePicture();
}