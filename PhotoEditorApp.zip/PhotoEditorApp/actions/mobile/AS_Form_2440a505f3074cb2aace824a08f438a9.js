function AS_Form_2440a505f3074cb2aace824a08f438a9(eventobject) {
    filter7.clearFilterData();
    filter8.clearFilterData();
    filter9.clearFilterData();
    frmblurIphone.destroy();
}