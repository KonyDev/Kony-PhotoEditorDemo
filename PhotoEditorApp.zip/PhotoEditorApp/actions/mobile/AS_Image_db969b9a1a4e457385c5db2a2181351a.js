function AS_Image_db969b9a1a4e457385c5db2a2181351a(eventobject, x, y) {
    setColorInversionAndroid();
    applyFilterttoImage(filter3);
}