function AS_Form_d26c08b330634f02b11a4bb4ac79eb38(eventobject) {
    frmBrightness.destroy();
}