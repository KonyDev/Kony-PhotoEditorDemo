function AS_Image_5d132842f92e49eba97ca1c3e6045a6c(eventobject, x, y) {
    undoImgProcess();
}