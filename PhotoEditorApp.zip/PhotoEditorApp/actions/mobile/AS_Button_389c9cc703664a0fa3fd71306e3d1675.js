function AS_Button_389c9cc703664a0fa3fd71306e3d1675(eventobject) {
    setBlurnessIphone(kony.filter.BOX_BLUR);
}