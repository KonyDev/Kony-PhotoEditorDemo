function AS_Image_2ba1d1893b37476a87b18bec99a3774c(eventobject, x, y) {
    colorstaus = "brightness";
    finalImageObject = finalImageObject1;
    setBrightnessFuncIphone();
}