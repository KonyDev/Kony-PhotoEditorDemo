function AS_Button_8503a27521564ae5aeaf2c5e8d6c2db7(eventobject) {
    setBlurnessIphone(kony.filter.GAUSSIAN_BLUR)
}