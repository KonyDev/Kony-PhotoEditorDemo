function AS_Button_b6b08eeb05ba4567916043448ef2a72f(eventobject) {
    return openGallery.call(this);
}