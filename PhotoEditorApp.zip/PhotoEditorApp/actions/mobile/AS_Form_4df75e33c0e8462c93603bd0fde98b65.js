function AS_Form_4df75e33c0e8462c93603bd0fde98b65(eventobject) {
    frmScaleFactor.destroy();
}