function AS_Button_d8fd4bd60ae84e1c89279968333bf57c(eventobject, x, y) {
    applyCropImage();
}