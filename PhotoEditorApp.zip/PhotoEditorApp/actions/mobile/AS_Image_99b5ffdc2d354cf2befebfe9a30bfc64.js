function AS_Image_99b5ffdc2d354cf2befebfe9a30bfc64(eventobject, x, y) {
    colorstaus = "hue";
    finalImageObject = finalImageObject1;
    setHueFuncIphone();
}