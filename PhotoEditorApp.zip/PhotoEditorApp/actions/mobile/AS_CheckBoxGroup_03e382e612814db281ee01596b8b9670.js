function AS_CheckBoxGroup_03e382e612814db281ee01596b8b9670(eventobject) {
    setVideoStabilization();
}