function AS_Image_011e388544b5404fa21475e5101091cc(eventobject, x, y) {
    applyFilterttoImageIphone(filter6);
}