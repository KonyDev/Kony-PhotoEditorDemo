function AS_Image_e958b67a572b4d3da9403d82e636f5fd(eventobject, x, y) {
    applyFilterttoImageIphone(filter3);
}