function AS_Button_cccf68d203c04de9a8aa1a184cd2c661(eventobject) {
    camera_captureSource_Toggle2();
}