function AS_Image_4d07e99af73d4d9dabd3068507f7e911(eventobject, x, y) {
    colorstaus = "simulation";
    finalImageObject = finalImageObject1;
    setSaturationFuncIphone();
}