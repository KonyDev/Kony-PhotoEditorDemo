function AS_Slider_c5ecf95f42024da5b6843fe5d3536967(eventobject, selectedvalue) {
    setColorfunIphione();
}