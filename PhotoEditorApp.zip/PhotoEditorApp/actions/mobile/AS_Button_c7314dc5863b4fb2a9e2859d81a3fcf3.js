function AS_Button_c7314dc5863b4fb2a9e2859d81a3fcf3(eventobject) {
    applyCropImage();
}