function AS_ListBox_ffd55e23a3f74ef48dc8e7bf09d5b8bd(eventobject) {
    camera_FlashMode();
}