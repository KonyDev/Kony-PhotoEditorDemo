function AS_Image_aa7d1906c2174c8ab9f35465c957b5b1(eventobject, x, y) {
    applyFilterttoImage(filter2);
}