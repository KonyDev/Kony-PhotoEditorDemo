function AS_ListBox_89430e0e22e64130aeb9811d074fe2cb(eventobject) {
    camera_videoQualityLevel();
}