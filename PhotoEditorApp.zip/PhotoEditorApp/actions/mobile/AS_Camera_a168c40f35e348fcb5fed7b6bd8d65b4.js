function AS_Camera_a168c40f35e348fcb5fed7b6bd8d65b4(eventobject) {
    return setCamerRawBytes.call(this, eventobject);
}