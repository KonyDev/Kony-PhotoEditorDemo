function AS_Button_ffd81da9b6e4446b9b64d141a5a0dbce(eventobject) {
    return openGallery.call(this);
}