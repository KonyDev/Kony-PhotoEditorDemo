function AS_Slider_0a3087a32c0c4390b028636445e5dbab(eventobject, selectedvalue) {
    onCropSlideFunc()
}