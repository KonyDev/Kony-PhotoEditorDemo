function AS_Button_54c903cffce7404e885c9c8cb4b0b773(eventobject) {
    navigatetoTwoImages();
}