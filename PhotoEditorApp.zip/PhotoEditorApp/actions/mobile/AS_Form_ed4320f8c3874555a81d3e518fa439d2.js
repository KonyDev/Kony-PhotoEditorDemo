function AS_Form_ed4320f8c3874555a81d3e518fa439d2(eventobject) {
    frmVideo.destroy();
}