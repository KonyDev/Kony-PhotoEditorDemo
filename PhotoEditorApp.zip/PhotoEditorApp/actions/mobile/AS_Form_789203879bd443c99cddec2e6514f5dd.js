function AS_Form_789203879bd443c99cddec2e6514f5dd(eventobject) {
    frmCropPreview.destroy();
}