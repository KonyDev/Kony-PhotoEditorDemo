function AS_Image_1695f78497544a409920c515b13caed6(eventobject, x, y) {
    applyFilterttoImage(filter2);
}