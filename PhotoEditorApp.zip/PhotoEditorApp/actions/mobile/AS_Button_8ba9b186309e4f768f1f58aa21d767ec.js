function AS_Button_8ba9b186309e4f768f1f58aa21d767ec(eventobject) {
    applyCropImage();
}