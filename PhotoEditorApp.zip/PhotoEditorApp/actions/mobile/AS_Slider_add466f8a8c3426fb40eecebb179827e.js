function AS_Slider_add466f8a8c3426fb40eecebb179827e(eventobject, selectedvalue) {
    onCropSlideFunc()
}