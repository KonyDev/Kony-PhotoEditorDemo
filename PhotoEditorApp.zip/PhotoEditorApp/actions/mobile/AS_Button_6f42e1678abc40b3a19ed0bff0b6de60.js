function AS_Button_6f42e1678abc40b3a19ed0bff0b6de60(eventobject) {
    navigatetoTwoImages();
}