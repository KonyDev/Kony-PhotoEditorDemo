function AS_Form_13f93673ef274eab871e6a14ec25e45a(eventobject) {
    frmBrightnessIPhone.destroy();
    colorstaus = undefined;
}