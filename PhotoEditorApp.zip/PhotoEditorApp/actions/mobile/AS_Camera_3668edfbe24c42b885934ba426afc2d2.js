function AS_Camera_3668edfbe24c42b885934ba426afc2d2(eventobject) {
    return openGalleryVideo.call(this);
}