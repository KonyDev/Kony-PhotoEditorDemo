function AS_Slider_ad88423d06674c31b815e77bae505e92(eventobject, selectedvalue) {
    onCropSlideFunc()
}