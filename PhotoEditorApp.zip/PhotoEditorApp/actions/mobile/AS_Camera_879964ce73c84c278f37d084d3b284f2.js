function AS_Camera_879964ce73c84c278f37d084d3b284f2(eventobject) {
    return setCamerRawBytes.call(this, eventobject);
}