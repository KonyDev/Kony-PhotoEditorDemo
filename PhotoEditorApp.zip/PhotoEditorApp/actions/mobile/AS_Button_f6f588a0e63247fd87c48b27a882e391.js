function AS_Button_f6f588a0e63247fd87c48b27a882e391(eventobject, x, y) {
    applyCropImage();
}