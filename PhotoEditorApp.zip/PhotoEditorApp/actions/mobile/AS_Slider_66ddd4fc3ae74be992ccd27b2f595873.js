function AS_Slider_66ddd4fc3ae74be992ccd27b2f595873(eventobject, selectedvalue) {
    onCropSlideFunc()
}