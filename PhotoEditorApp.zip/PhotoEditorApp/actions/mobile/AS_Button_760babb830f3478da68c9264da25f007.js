function AS_Button_760babb830f3478da68c9264da25f007(eventobject) {
    navigatetoBlurness();
}