function AS_Button_6dbb497fa1f44c7ab95396f5f744703b(eventobject) {
    cropImage();
}