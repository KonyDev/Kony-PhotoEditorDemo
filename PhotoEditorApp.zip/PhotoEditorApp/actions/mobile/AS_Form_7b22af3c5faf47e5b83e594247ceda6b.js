function AS_Form_7b22af3c5faf47e5b83e594247ceda6b(eventobject) {
    frmblurAndroid.destroy();
}