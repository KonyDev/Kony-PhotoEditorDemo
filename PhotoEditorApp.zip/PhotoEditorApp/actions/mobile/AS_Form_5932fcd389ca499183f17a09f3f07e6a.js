function AS_Form_5932fcd389ca499183f17a09f3f07e6a(eventobject) {
    filter2.clearFilterData();
    filter3.clearFilterData();
    filter4.clearFilterData();
    frmeffectsAndroid.destroy();
}