function AS_Form_ebd741c1e5b64f4aafb511f0fcf057cd(eventobject) {
    frmblurAndroid.destroy();
}