function AS_Button_543c70aeeb764c0a88e2f97aaf24ed8b(eventobject) {
    camera_captureSource_Toggle2();
}