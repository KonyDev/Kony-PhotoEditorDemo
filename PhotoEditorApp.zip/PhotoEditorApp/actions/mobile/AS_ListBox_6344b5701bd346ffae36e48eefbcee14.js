function AS_ListBox_6344b5701bd346ffae36e48eefbcee14(eventobject) {
    setFocusMode();
}