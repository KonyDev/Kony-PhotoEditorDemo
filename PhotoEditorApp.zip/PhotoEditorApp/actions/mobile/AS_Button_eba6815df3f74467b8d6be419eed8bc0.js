function AS_Button_eba6815df3f74467b8d6be419eed8bc0(eventobject) {
    navigatetoEffects();
}