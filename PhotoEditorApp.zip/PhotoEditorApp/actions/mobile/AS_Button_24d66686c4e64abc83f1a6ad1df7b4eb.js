function AS_Button_24d66686c4e64abc83f1a6ad1df7b4eb(eventobject) {
    navigatetoBrightness();
}