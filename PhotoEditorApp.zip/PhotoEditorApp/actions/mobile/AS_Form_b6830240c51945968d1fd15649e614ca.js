function AS_Form_b6830240c51945968d1fd15649e614ca() {
    frmHome.Camera0b80625cf993243.focusMode = constants.CAMERA_FOCUS_MODE_AUTO;
}