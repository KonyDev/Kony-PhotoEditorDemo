function AS_Form_bd04d313bb2145ae8ad629e680e380cd(eventobject) {
    filter2.clearFilterData();
    filter3.clearFilterData();
    filter4.clearFilterData();
    filter5.clearFilterData();
    filter6.clearFilterData();
    frmeffectsIphone.destroy();
}