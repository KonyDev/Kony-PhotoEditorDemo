function AS_Button_52a14681e2bf49b282bffbe4fa0364e8(eventobject) {
    navigatetoBrightness();
}