function AS_Image_3747dfc2285a457ba189dff5c4f2a370(eventobject, x, y) {
    frm2.show();
}