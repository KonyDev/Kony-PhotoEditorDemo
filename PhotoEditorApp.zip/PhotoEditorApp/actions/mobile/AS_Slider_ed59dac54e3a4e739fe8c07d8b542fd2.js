function AS_Slider_ed59dac54e3a4e739fe8c07d8b542fd2(eventobject, selectedvalue) {
    setBlurness();
}