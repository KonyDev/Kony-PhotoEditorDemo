function AS_Button_cb77a3a08fc64f71a04b2058556a1de0(eventobject) {
    return openGallery.call(this);
}