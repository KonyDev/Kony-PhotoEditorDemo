function AS_ListBox_f0a231c6511f4c89b8a1fde9a4ad372d(eventobject) {
    camera_videoFormatProperty();
}