function AS_Form_b087f55acdfb4e3daa28d363cd4b13dd() {
    frmOverlay.FrontCamera.cameraOptions = {
        hideControlBar: true
    };
    frmOverlay1.RearCamera.cameraOptions = {
        hideControlBar: true
    };
}