function AS_Image_8357a2af361b4061b82d41e6dcf10b78(eventobject, x, y) {
    setCompositionEditor(kony.filter.MULTIPLY_COMPOSITING);
}