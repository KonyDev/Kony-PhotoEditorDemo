function AS_Image_6ba20191bcbb4e21b54079c8b8aa6e7b(eventobject, x, y) {
    applyFilterttoImageIphone(filter4);
}