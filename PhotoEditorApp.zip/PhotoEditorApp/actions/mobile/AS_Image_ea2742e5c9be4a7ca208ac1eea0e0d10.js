function AS_Image_ea2742e5c9be4a7ca208ac1eea0e0d10(eventobject, x, y) {
    setBlurness(20);
}