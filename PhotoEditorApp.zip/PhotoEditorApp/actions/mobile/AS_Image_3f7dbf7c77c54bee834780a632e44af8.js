function AS_Image_3f7dbf7c77c54bee834780a632e44af8(eventobject, x, y) {
    applyFilterttoImageIphone(filter2);
}