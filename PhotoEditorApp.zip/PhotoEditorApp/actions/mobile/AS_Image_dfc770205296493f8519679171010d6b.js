function AS_Image_dfc770205296493f8519679171010d6b(eventobject, x, y) {
    colorstaus = "contrast";
    finalImageObject = finalImageObject1;
    setContrastFuncIphone();
}