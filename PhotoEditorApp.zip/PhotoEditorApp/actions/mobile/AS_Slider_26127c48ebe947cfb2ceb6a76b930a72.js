function AS_Slider_26127c48ebe947cfb2ceb6a76b930a72(eventobject, selectedvalue) {
    setBlurness();
}