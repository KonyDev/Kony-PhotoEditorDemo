function AS_Slider_33dc106752824a848999f794c67a8165(eventobject, selectedvalue) {
    setBlurnessIphone();
}