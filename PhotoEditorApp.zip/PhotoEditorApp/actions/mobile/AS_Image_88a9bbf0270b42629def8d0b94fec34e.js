function AS_Image_88a9bbf0270b42629def8d0b94fec34e(eventobject, x, y) {
    applyBulrImageIphone(filter7);
}