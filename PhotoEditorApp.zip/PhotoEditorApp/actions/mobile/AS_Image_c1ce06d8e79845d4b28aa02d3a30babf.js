function AS_Image_c1ce06d8e79845d4b28aa02d3a30babf(eventobject, x, y) {
    setCompositionEditor(kony.filter.DARKEN_COMPOSITING);
}