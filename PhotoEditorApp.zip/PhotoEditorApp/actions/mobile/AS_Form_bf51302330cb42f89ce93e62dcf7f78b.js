function AS_Form_bf51302330cb42f89ce93e62dcf7f78b(eventobject) {
    frmScaleFactor.destroy();
}