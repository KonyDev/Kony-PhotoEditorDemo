function AS_Button_5d38ee2d73964cd7ab752b50d23a4107(eventobject) {
    camera_captureSource_Toggle();
}