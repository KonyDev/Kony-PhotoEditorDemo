function AS_Image_331b5005c8874d50b8cb44b52047aca1(eventobject, x, y) {
    applyBulrImageIphone(filter7);
}