function AS_Slider_c58227c44e2a4ffaa987a62fd865627d(eventobject, selectedvalue) {
    setVideoDuration();
}