function AS_Button_33818fc7da70471784d120b7509dda2b(eventobject) {
    navigatetoBlurness();
}