function AS_Image_2ba772f530824081b6528422cd79cdef(eventobject, x, y) {
    setCompositionEditor(kony.filter.SOURCE_ATOP_COMPOSITING);
}