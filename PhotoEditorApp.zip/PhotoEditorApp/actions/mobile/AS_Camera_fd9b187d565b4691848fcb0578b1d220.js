function AS_Camera_fd9b187d565b4691848fcb0578b1d220(eventobject) {
    frmHome.show();
}