function AS_Form_94f594e237b7486fb2ff94733ed96e8e(eventobject) {
    frmtwoImagesIphone.destroy();
}