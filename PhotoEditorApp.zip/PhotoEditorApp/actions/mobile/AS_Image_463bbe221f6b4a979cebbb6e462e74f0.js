function AS_Image_463bbe221f6b4a979cebbb6e462e74f0(eventobject, x, y) {
    applyBulrImageIphone(filter9);
}