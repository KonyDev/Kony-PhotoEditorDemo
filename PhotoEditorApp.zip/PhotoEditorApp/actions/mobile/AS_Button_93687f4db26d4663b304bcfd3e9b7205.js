function AS_Button_93687f4db26d4663b304bcfd3e9b7205(eventobject) {
    setBlurnessIphone(kony.filter.MOTION_BLUR);
}