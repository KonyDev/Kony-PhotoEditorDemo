function AS_Image_e958f5ddbf7f4cd4b93cdb5f76df08e4(eventobject, x, y) {
    redoImgProces();
}