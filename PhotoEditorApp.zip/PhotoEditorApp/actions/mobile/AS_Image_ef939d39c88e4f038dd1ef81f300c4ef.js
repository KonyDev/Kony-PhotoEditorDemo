function AS_Image_ef939d39c88e4f038dd1ef81f300c4ef(eventobject, x, y) {
    setColorInversionAndroid();
    applyFilterttoImage(filter3);
}