function AS_Button_8335a659d15649819209ce6db2df079d(eventobject) {
    camera_captureSource_Toggle();
}