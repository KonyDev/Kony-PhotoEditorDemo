function AS_Form_d0bf141da6d6431da4e66b5a69e2604d(eventobject) {
    frmBrightnessIPhone.destroy();
    colorstaus = undefined;
}