function AS_CheckBoxGroup_a30e737118764d18ac53aaca4fb73218(eventobject) {
    setVideoStabilization();
}