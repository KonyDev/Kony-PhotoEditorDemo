function AS_ListBox_f6591537387a4c18a741157756a487d9(eventobject) {
    camera_videoQualityLevel();
}