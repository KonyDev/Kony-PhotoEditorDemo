function AS_ListBox_01afbcfe65614d1eafc1a90922ac784f(eventobject) {
    camera_videoQualityLevel();
}