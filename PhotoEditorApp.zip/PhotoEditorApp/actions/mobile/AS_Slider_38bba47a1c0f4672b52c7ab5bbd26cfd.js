function AS_Slider_38bba47a1c0f4672b52c7ab5bbd26cfd(eventobject, selectedvalue) {
    setVideoDuration();
}