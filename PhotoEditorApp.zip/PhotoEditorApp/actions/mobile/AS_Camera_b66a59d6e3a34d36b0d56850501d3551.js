function AS_Camera_b66a59d6e3a34d36b0d56850501d3551(eventobject) {
    return setCamerRawBytes.call(this, eventobject);
}