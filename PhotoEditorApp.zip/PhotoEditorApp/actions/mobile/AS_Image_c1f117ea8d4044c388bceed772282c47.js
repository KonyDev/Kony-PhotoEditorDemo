function AS_Image_c1f117ea8d4044c388bceed772282c47(eventobject, x, y) {
    setCompositionEditor(kony.filter.CLEAR_COMPOSITING);
}