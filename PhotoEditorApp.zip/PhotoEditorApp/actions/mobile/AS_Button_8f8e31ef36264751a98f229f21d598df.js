function AS_Button_8f8e31ef36264751a98f229f21d598df(eventobject) {
    cropImage();
}