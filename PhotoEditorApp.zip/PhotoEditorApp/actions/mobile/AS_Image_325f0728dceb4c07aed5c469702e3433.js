function AS_Image_325f0728dceb4c07aed5c469702e3433(eventobject, x, y) {
    setBlurness(8);
}