function AS_ListBox_fa1690f26a70432aaf9a74b1e3bc2313(eventobject) {
    camera_videoQualityLevel();
}