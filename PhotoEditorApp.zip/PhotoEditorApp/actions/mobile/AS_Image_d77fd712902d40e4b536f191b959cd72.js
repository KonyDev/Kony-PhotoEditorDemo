function AS_Image_d77fd712902d40e4b536f191b959cd72(eventobject, x, y) {
    applyFilterttoImage(filter1);
}