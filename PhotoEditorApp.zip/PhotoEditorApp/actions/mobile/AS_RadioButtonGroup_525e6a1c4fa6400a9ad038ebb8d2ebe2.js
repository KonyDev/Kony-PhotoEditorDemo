function AS_RadioButtonGroup_525e6a1c4fa6400a9ad038ebb8d2ebe2(eventobject) {
    setCompositionEditorIphone(frmtwoImagesIphone.RadioButtonGroup09b7e6319b35d43.selectedKeyValue[0]);
}