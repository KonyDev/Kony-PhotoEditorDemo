function AS_Form_09ca349dc29c4070a6c661de19f9f244(eventobject) {
    frmtwoImagesIphone.destroy();
}