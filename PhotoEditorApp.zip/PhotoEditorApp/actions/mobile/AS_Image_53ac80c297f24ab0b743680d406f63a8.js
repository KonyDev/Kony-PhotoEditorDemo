function AS_Image_53ac80c297f24ab0b743680d406f63a8(eventobject, x, y) {
    colorstaus = "contrast";
    finalImageObject = finalImageObject1;
    setContrastFuncIphone();
}