function AS_Image_a503366dae444775b4dae32e8736cd5a(eventobject, x, y) {
    setBlurness(5);
}