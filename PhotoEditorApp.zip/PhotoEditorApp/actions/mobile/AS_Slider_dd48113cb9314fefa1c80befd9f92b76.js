function AS_Slider_dd48113cb9314fefa1c80befd9f92b76(eventobject, selectedvalue) {
    onCropSlideFunc()
}