function AS_Image_944125762f194487892a068e0dab4bee(eventobject, x, y) {
    setCompositionEditor(kony.filter.LIGHTEN_COMPOSITING);
}