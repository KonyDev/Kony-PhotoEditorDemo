function AS_Button_2b9d801a9c4c466397c1901282432c65(eventobject) {
    applyCropImage();
}