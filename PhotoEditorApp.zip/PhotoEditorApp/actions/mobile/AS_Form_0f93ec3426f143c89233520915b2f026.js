function AS_Form_0f93ec3426f143c89233520915b2f026(eventobject) {
    filter2.clearFilterData();
    filter3.clearFilterData();
    filter4.clearFilterData();
    frmeffectsAndroid.destroy();
}