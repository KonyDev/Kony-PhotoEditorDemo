function AS_Image_65f13aac271d4d3798f5ecb5fc7d754b(eventobject, x, y) {
    setColorClampAndroid();
    applyFilterttoImage(filter4);
}