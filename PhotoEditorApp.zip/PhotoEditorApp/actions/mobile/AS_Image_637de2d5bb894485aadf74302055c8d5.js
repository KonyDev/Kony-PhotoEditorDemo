function AS_Image_637de2d5bb894485aadf74302055c8d5(eventobject, x, y) {
    setBlurness(15);
}