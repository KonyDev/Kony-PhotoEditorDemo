function AS_Image_09077f2c96964a6982f51397fef90edf(eventobject, x, y) {
    setCompositionEditor(kony.filter.CLEAR_COMPOSITING);
}