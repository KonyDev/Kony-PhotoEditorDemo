function AS_Image_cb73bd6900744a55a59b697e696b7462(eventobject, x, y) {
    frmHome.show();
}