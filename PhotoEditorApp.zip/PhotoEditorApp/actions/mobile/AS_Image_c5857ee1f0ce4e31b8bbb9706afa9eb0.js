function AS_Image_c5857ee1f0ce4e31b8bbb9706afa9eb0(eventobject, x, y) {
    applyFilterttoImageIphone(filter5);
}