function AS_Form_961bb0024bad4e0bac5b317a40b6dec2() {
    setRearCamera();
}