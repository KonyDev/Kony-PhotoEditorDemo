function AS_Slider_914ae350ee3541f29651dab30c0a2e32(eventobject, selectedvalue) {
    onCropSlideFunc()
}