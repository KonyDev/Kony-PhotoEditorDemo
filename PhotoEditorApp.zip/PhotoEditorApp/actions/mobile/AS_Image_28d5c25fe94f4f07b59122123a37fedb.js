function AS_Image_28d5c25fe94f4f07b59122123a37fedb(eventobject, x, y) {
    applyBulrImageIphone(filter8);
}