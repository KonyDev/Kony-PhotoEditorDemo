function AS_Image_2ba86f55cd4a4244b2d2b26261641f07(eventobject, x, y) {
    applyFilterttoImageIphone(filter1);
}