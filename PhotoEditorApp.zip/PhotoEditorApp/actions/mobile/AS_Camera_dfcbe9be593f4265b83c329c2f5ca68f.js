function AS_Camera_dfcbe9be593f4265b83c329c2f5ca68f(eventobject) {
    return setCamerRawBytes.call(this, eventobject);
}