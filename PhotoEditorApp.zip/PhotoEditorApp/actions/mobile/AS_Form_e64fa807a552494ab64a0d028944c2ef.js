function AS_Form_e64fa807a552494ab64a0d028944c2ef(eventobject) {
    frmBrightness.destroy();
}