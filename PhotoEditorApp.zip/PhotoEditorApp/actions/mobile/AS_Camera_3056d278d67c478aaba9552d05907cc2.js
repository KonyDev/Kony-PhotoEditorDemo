function AS_Camera_3056d278d67c478aaba9552d05907cc2(eventobject) {
    return setCamerRawBytes.call(this, eventobject);
}