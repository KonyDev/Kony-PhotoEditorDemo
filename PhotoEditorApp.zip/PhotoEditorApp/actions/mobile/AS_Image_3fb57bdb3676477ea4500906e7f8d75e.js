function AS_Image_3fb57bdb3676477ea4500906e7f8d75e(eventobject, x, y) {
    applyFilterttoImageIphone(filter6);
}