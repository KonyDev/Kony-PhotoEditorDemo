function AS_Button_c3c0d9457d8a46a4b849f4947bdc3e81(eventobject) {
    navigatetoEffects();
}