function AS_ListBox_7476890a821c4e2aa1649bef2078851b(eventobject) {
    camera_FlashMode();
}