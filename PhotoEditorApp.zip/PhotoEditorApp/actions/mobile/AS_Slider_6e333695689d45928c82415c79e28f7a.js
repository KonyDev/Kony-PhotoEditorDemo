function AS_Slider_6e333695689d45928c82415c79e28f7a(eventobject, selectedvalue) {
    onCropSlideFunc();
}