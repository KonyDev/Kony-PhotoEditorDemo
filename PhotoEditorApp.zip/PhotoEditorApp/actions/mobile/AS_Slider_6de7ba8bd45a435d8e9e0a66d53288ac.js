function AS_Slider_6de7ba8bd45a435d8e9e0a66d53288ac(eventobject, selectedvalue) {
    setVideoDuration();
}