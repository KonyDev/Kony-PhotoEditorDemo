function AS_Image_fce3a0cda45d4ce082fb600cf2fe0b0d(eventobject, x, y) {
    setCompositionEditor(kony.filter.XOR_COMPOSITING);
}