function AS_Button_b46c0c7da77144f2ac7a49aeedade6d1(eventobject) {
    NavigateScaleForm();
}