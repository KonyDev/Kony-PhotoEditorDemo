function AS_Camera_5885d6edcda442ecb0226586d7900b0b(eventobject) {
    return setCamerRawBytes.call(this, null);
}