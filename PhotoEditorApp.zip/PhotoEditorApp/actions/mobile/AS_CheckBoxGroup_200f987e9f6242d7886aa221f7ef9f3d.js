function AS_CheckBoxGroup_200f987e9f6242d7886aa221f7ef9f3d(eventobject) {
    setVideoStabilization();
}