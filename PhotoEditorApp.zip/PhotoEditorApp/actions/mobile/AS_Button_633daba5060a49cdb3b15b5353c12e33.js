function AS_Button_633daba5060a49cdb3b15b5353c12e33(eventobject) {
    applyAdjustImage();
}