function AS_Image_cfde773448e34a7ab52a4e80ae8cc962(eventobject, x, y) {
    applyBulrImageIphone(filter9);
}