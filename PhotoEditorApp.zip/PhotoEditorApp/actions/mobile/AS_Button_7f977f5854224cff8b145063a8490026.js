function AS_Button_7f977f5854224cff8b145063a8490026(eventobject) {
    frmOverlay.FrontCamera.takePicture();
}