function AS_Form_725e8a3fd53041588656f5afd6bb74ad(eventobject) {
    filter2.clearFilterData();
    filter3.clearFilterData();
    filter4.clearFilterData();
    filter5.clearFilterData();
    filter6.clearFilterData();
    frmeffectsIphone.destroy();
}