function AS_Image_2eb8fd3f45c1419db70367bd1c7e7b46(eventobject, x, y) {
    applyFilterttoImageIphone(filter4);
}