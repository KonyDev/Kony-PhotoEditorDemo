function AS_Button_27f0d060e9594ccdb82b4f4eb6a73110(eventobject) {
    NavigateScaleForm();
}