function AS_Image_facf18dcb9ea441aa257769954a90916(eventobject, x, y) {
    setCompositionEditor(kony.filter.LIGHTEN_COMPOSITING);
}