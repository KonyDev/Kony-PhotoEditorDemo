function AS_Slider_7dbbfec5b0924a95bf092421a7d6758d(eventobject, selectedvalue) {
    ScalefactorFunc();
}