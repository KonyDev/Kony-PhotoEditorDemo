function AS_Image_2f3af51fd458400bbff7d54215ff0ebd(eventobject, x, y) {
    setCompositionEditor(kony.filter.XOR_COMPOSITING);
}