function AS_Form_a927c9f11f9945a2897837eed685f481() {
    retrieveQualityLevels();
}