function AS_Form_d40e919005e34ca78ca90b836e98d30d(eventobject) {
    frmVideo.destroy();
}