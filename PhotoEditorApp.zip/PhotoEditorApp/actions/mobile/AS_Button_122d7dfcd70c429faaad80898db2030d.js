function AS_Button_122d7dfcd70c429faaad80898db2030d(eventobject, x, y) {
    applyCropImage();
}