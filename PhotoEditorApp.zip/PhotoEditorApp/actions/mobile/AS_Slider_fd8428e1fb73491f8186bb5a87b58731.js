function AS_Slider_fd8428e1fb73491f8186bb5a87b58731(eventobject, selectedvalue) {
    ScalefactorFunc();
}