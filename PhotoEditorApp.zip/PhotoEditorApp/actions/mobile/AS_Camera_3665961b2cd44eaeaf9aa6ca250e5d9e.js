function AS_Camera_3665961b2cd44eaeaf9aa6ca250e5d9e(eventobject) {
    return setCamerRawBytes.call(this, eventobject);
}