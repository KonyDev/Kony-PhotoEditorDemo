function AS_Button_c049ffc9cdd948a9bf79f28fb77e7650(eventobject) {
    applyAdjustImage();
}