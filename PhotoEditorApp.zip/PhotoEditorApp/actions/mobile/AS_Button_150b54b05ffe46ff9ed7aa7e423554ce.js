function AS_Button_150b54b05ffe46ff9ed7aa7e423554ce(eventobject) {
    takePictureAPI();
}