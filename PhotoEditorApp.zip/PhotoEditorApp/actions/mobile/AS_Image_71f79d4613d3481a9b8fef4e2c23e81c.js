function AS_Image_71f79d4613d3481a9b8fef4e2c23e81c(eventobject, x, y) {
    applyBulrImageIphone(filter8);
}