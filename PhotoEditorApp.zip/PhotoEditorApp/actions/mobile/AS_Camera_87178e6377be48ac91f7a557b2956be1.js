function AS_Camera_87178e6377be48ac91f7a557b2956be1(eventobject) {
    return setCamerRawBytes.call(this, eventobject);
}