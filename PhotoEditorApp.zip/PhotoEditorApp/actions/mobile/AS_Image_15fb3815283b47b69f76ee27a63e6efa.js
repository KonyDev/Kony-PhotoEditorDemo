function AS_Image_15fb3815283b47b69f76ee27a63e6efa(eventobject, x, y) {
    colorstaus = "brightness";
    finalImageObject = finalImageObject1;
    setBrightnessFuncIphone();
}