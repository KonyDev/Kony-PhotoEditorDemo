function AS_Slider_d913ff84ec194a3b8e705a278bf056e2(eventobject, selectedvalue) {
    setVideoDuration();
}