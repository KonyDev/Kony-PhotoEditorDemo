function AS_Image_86e62977867642f3b10edbdd85b5c5c0(eventobject, x, y) {
    frmHome.show();
}