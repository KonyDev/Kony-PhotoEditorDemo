function AS_Form_c0b449e91a544218a3f4c0262da249d3(eventobject) {
    frmVideo.destroy();
}