function AS_RadioButtonGroup_682f470507c84b6a8f4ef33b32ef3110(eventobject) {
    setCompositionEditorIphone(frmtwoImagesIphone.RadioButtonGroup09b7e6319b35d43.selectedKeyValue[0]);
}