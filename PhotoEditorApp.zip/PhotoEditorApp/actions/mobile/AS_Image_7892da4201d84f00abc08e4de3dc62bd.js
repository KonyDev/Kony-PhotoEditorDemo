function AS_Image_7892da4201d84f00abc08e4de3dc62bd(eventobject, x, y) {
    applyFilterttoImageIphone(filter3);
}