function AS_Form_8f5629887abb4a96a8454a82f8ca5a46(eventobject) {
    filter7.clearFilterData();
    filter8.clearFilterData();
    filter9.clearFilterData();
    frmblurIphone.destroy();
}